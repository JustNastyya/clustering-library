# SPDX-FileCopyrightText: 2025-present Anastasiia Romanenko <romanenko.a.e.04@gmail.com>
#
# SPDX-License-Identifier: MIT
