# clustering

[![PyPI - Version](https://img.shields.io/pypi/v/clustering.svg)](https://pypi.org/project/clustering)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/clustering.svg)](https://pypi.org/project/clustering)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install clustering
```

## License

`clustering` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
